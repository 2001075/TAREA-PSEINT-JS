const leer = require("prompt-sync")();

class Ejercicios {
  ejercicio1() {
    let a, b, c, resultado;

    a = parseFloat(leer("Digite el valor A: "));
    b = parseFloat(leer("Digite el valor B: "));
    c = parseFloat(leer("Digite el valor C: "));

    resultado = (-b + Math.sqrt(b ** 2 - 4 * a * c)) / (2 * a);

    console.log("El resultado es:", resultado);
  }
  ejercicio2() {
    let a, b;
    let resultado;

    console.log("Digite el valor de a: ");
    a = parseFloat(leer());
    console.log("Digite el valor de b: ");
    b = parseFloat(leer());

    resultado = (3 + 5 * 8 < 3 && (-6 / 3) * 4 + 2 < 2) || a > b;

    console.log("El resultado es:", resultado);
  }

  ejercicio3() {
    let a, b;
    let aux;

    console.log("Digite el valor de a: ");
    a = parseInt(leer());
    console.log("Digite el valor de b: ");
    b = parseInt(leer());

    aux = a;
    a = b;
    b = aux;

    console.log("El nuevo valor de a es:", a);
    console.log("El nuevo valor de b es:", b);
  }

  ejercicio4() {
    let a, b, c;
    a = 10;
    b = 20;

    console.log("Digite un número:");
    c = parseInt(leer());

    let resultado = a + b + c;

    console.log("El resultado es:", resultado);
  }

  ejercicio5() {
    let a, b, resultado;
    a = 10;

    console.log("Digite un número:");
    b = parseInt(leer());

    resultado = a + b;

    console.log("El resultado es:", resultado);
  }

  ejercicio6() {
    let a, b, resultado;
    a = 10;

    console.log("Digite el número:");
    b = parseInt(leer());

    resultado = a + b;

    console.log("El resultado es:", resultado);
  }

  ejercicio7() {
    let horas, minutos, seg;
    let horas_seg, minutos_seg, total_seg;

    console.log("Digite las horas:");
    horas = parseInt(leer());

    console.log("Digite los minutos:");
    minutos = parseInt(leer());

    console.log("Digite los segundos:");
    seg = parseInt(leer());

    horas_seg = horas * 3600;
    minutos_seg = minutos * 60;
    total_seg = horas_seg + minutos_seg + seg;

    console.log("Los segundos equivalentes son:", total_seg);
  }

  ejercicio8() {
    const pi = Math.PI;
    let radio, area, lon;

    console.log("Digite el valor del radio:");
    radio = parseFloat(leer());

    area = pi * radio ** 2;
    lon = 2 * pi * radio;

    console.log("El área de la circunferencia es:", area);
    console.log("La longitud es:", lon);
  }

  ejercicio9() {
    let num_hombres, num_mujeres;
    let total_estudiantes;
    let porcentajeH, porcentajeM;

    console.log("Digite el número de hombres:");
    num_hombres = parseInt(leer());

    console.log("Digite el número de mujeres:");
    num_mujeres = parseInt(leer());

    total_estudiantes = num_hombres + num_mujeres;

    porcentajeH = (num_hombres / total_estudiantes) * 100;
    porcentajeM = (num_mujeres / total_estudiantes) * 100;

    console.log("El porcentaje de hombres es:", porcentajeH.toFixed(2), "%");
    console.log("El porcentaje de mujeres es:", porcentajeM.toFixed(2), "%");
  }

  ejercicio10() {
    let cantidadA, cantidadB, cantidadC;
    let tiempoA, tiempoB, tiempoC;
    let tiempo_total;
    let horas, minutos;

    console.log("Digite la cantidad de cuestionarios A:");
    cantidadA = parseInt(leer());

    console.log("Digite la cantidad de cuestionarios B:");
    cantidadB = parseInt(leer());

    console.log("Digite la cantidad de cuestionarios C:");
    cantidadC = parseInt(leer());

    tiempoA = cantidadA * 5;
    tiempoB = cantidadB * 8;
    tiempoC = cantidadC * 6;

    tiempo_total = tiempoA + tiempoB + tiempoC;

    horas = Math.trunc(tiempo_total / 60);
    minutos = tiempo_total % 60;

    console.log(
      "Se tardará",
      horas,
      "horas y",
      minutos,
      "minutos en revisar todos los cuestionarios."
    );
  }

  ejercicio11() {
    let precio, descuento, precio_final;

    console.log("Digite el precio a pagar:");
    precio = parseFloat(leer());

    descuento = precio * 0.15;
    precio_final = precio - descuento;

    console.log("El precio a pagar es de:", precio_final);
  }

  ejercicio12() {
    let parcial1, parcial2, parcial3, promedioP, notasParcial;
    let examen_final, notaExamen;
    let notaTrabajo, notaFinalTrabajo;
    let notaFinal;

    console.log("Digite las 3 notas de los parciales:");
    parcial1 = parseFloat(leer());
    parcial2 = parseFloat(leer());
    parcial3 = parseFloat(leer());

    promedioP = (parcial1 + parcial2 + parcial3) / 3;
    notasParcial = promedioP * 0.55;

    console.log("Digite la nota del examen final:");
    examen_final = parseFloat(leer());

    notaExamen = examen_final * 0.3;

    console.log("Digite la nota del trabajo final:");
    notaTrabajo = parseFloat(leer());

    notaFinalTrabajo = notaTrabajo * 0.15;

    notaFinal = notasParcial + notaExamen + notaFinalTrabajo;

    console.log("La calificación final es:", notaFinal);
  }

  ejercicio13() {
    let num;

    console.log("Digite un número:");
    num = parseInt(leer());

    if (num % 2 === 0) {
      console.log("El número", num, "es par");
    } else {
      console.log("El número", num, "es impar");
    }
  }

  ejercicio14() {
    let nota1, nota2, nota3;
    let promedio;

    console.log("Digite las 3 calificaciones:");
    nota1 = parseFloat(leer());
    nota2 = parseFloat(leer());
    nota3 = parseFloat(leer());

    promedio = (nota1 + nota2 + nota3) / 3;

    if (promedio >= 70) {
      console.log("El alumno está aprobado con un promedio de:", promedio);
    } else {
      console.log("El alumno está desaprobado con un promedio de:", promedio);
    }
  }

  ejercicio15() {
    let compra;
    let descuento, precio_final;

    console.log("Digite la cantidad a pagar:");
    compra = parseFloat(leer());

    if (compra > 100) {
      descuento = compra * 0.2;
    } else {
      descuento = 0;
    }

    precio_final = compra - descuento;

    console.log("El precio a pagar es:", precio_final);
  }

  ejercicio16() {
    let num1, num2, resultado;

    console.log("Digite dos números:");
    num1 = parseFloat(leer());
    num2 = parseFloat(leer());

    if (num1 === num2) {
      resultado = num1 * num2;
    } else {
      if (num1 > num2) {
        resultado = num1 - num2;
      } else {
        resultado = num1 + num2;
      }
    }

    console.log("El resultado es:", resultado);
  }

  ejercicio17() {
    let num1, num2, num3;

    console.log("Digite tres números diferentes:");
    num1 = parseFloat(leer());
    num2 = parseFloat(leer());
    num3 = parseFloat(leer());

    if (num1 > num2 && num1 > num3) {
      console.log("El mayor es:", num1);
    } else {
      if (num2 > num1 && num2 > num3) {
        console.log("El mayor es:", num2);
      } else {
        console.log("El mayor es:", num3);
      }
    }
  }

  ejercicio18() {
    let precioK, kilos, precioI;
    let descuento, precio_final;

    console.log("¿Cuánto cuesta el kilo de manzanas?");
    precioK = parseFloat(leer());

    console.log("¿Cuántos kilos de manzanas has comprado?");
    kilos = parseFloat(leer());

    precioI = precioK * kilos;

    if (kilos >= 0 && kilos <= 2) {
      descuento = 0;
    } else if (kilos >= 2.01 && kilos <= 5) {
      descuento = precioI * 0.1;
    } else if (kilos >= 5.01 && kilos <= 10) {
      descuento = precioI * 0.15;
    } else {
      descuento = precioI * 0.2;
    }

    precio_final = precioI - descuento;

    console.log("El precio a pagar es: $" + precio_final);
  }

  ejercicio19() {
    let num;

    console.log("Ingrese un número del día de la semana (1-7):");
    num = parseInt(leer());

    switch (num) {
      case 1:
        console.log("Lunes");
        break;
      case 2:
        console.log("Martes");
        break;
      case 3:
        console.log("Miércoles");
        break;
      case 4:
        console.log("Jueves");
        break;
      case 5:
        console.log("Viernes");
        break;
      case 6:
        console.log("Sábado");
        break;
      case 7:
        console.log("Domingo");
        break;
      default:
        console.log("Error, no existe día para ese número");
    }
  }

  ejercicio20() {
    let decada;

    console.log("Digite una década:");
    decada = parseInt(leer());

    switch (decada) {
      case 10:
        console.log("Bodas de hojalata");
        break;
      case 20:
        console.log("Bodas de porcelana");
        break;
      case 30:
        console.log("Bodas de perlas");
        break;
      case 40:
        console.log("Bodas de rubí");
        break;
      case 50:
        console.log("Bodas de oro");
        break;
      case 60:
        console.log("Bodas de diamantes");
        break;
      default:
        console.log("Década no existente");
    }
  }

  ejercicio21() {
    let opcion;

    console.log("Menu");
    console.log("1. Elevar un número a una potencia x");
    console.log("2. Sacar la raíz cuadrada de un número");
    console.log("3. Salir");
    console.log("Digite una opción:");

    opcion = parseInt(leer());

    switch (opcion) {
      case 1:
        let num, pot, resultado;
        console.log("Digite un número:");
        num = parseInt(leer());
        console.log("Digite la potencia:");
        pot = parseInt(leer());
        resultado = Math.pow(num, pot);
        console.log("El resultado es:", resultado);
        break;
      case 2:
        let num2, resultado2;
        console.log("Digite un número:");
        num2 = parseInt(leer());
        resultado2 = Math.sqrt(num2);
        console.log("El resultado es:", resultado2);
        break;
      case 3:
        console.log("Saliendo del programa...");
        break;
      default:
        console.log("Opción inválida");
    }
  }

  ejercicio22() {
    for (let i = 1; i <= 10; i++) {
      console.log(i);
    }
  }

  ejercicio23() {
    let i = 1;
    while (i <= 10) {
      console.log(i);
      i = i + 1;
    }
  }

  ejercicio24() {
    let N = parseInt(prompt("Ingrese la cantidad de números a sumar:"));
    let suma = 0;

    for (let i = 1; i <= N; i++) {
      suma = suma + i;
    }

    console.log("La suma es:", suma);
  }

  ejercicio25() {
    let suma_pares = 0;
    let suma_impares = 0;

    for (let i = 2; i <= 49; i++) {
      if (i % 2 === 0) {
        suma_pares = suma_pares + i;
      } else {
        suma_impares = suma_impares + i;
      }
    }

    console.log("La suma de los números pares es:", suma_pares);
    console.log("La suma de los números impares es:", suma_impares);
  }

  ejercicio26() {
    let conteo_positivos = 0;
    let conteo_negativos = 0;
    let conteo_neutros = 0;

    for (let i = 1; i <= 10; i++) {
      console.log(i + ". Digite un número:");
      let num = parseInt(leer());

      if (num === 0) {
        conteo_neutros++;
      } else if (num > 0) {
        conteo_positivos++;
      } else {
        conteo_negativos++;
      }
    }

    console.log("La cantidad de números positivos es:", conteo_positivos);
    console.log("La cantidad de números negativos es:", conteo_negativos);
    console.log("La cantidad de números neutros es:", conteo_neutros);
  }

  ejercicio27() {
    let calificacion_promedio = 0;
    let calificacion_baja = 99999;
    let suma = 0;

    for (let i = 1; i <= 10; i++) {
      console.log(i + ". Digite una calificación:");
      let calificacion = parseFloat(leer());

      suma += calificacion;

      if (calificacion < calificacion_baja) {
        calificacion_baja = calificacion;
      }
    }

    calificacion_promedio = suma / 10;

    console.log("La calificación promedio es:", calificacion_promedio);
    console.log("La calificación más baja es:", calificacion_baja);
  }

  ejercicio28() {
    let num;
    do {
      console.log("Digite un número:");
      num = parseInt(leer());
    } while (num < 0);

    let i = 1;
    let factorial = 1;

    while (i <= num) {
      factorial *= i;
      i++;
    }

    console.log("El factorial es:", factorial);
  }

  ejercicio29() {
    let n_elementos;
    let i, suma;
    console.log("Digite la cantidad de elementos a sumarse:");
    n_elementos = parseInt(leer());
    i = 1;
    suma = 0;
    while (i <= n_elementos) {
      suma += Math.pow(i, 2);
      i++;
    }
    console.log("La suma es:", suma);
  }

  ejercicio30() {
    let n_elementos;
    let i, num;
    let suma_pares, conteo_pares;
    let suma_impares, conteo_impares;
    let promedio_impares;
    console.log("Digite la cantidad de elementos a ingresar:");
    n_elementos = parseInt(leer());
    i = 1;
    suma_pares = 0;
    conteo_pares = 0;
    suma_impares = 0;
    conteo_impares = 0;
    while (i <= n_elementos) {
      console.log(i + ". Digite un número:");
      num = parseInt(leer());
      if (num % 2 === 0) {
        // El número es par
        suma_pares += num;
        conteo_pares++;
      } else {
        // El número es impar
        suma_impares += num;
        conteo_impares++;
      }
      i++;
    }
    if (conteo_pares === 0) {
      console.log("No se han digitado números pares.");
    } else {
      console.log("La suma de los números pares es:", suma_pares);
      console.log("El conteo de los números pares es:", conteo_pares);
    }
    if (conteo_impares === 0) {
      console.log("No se han digitado números impares.");
    } else {
      promedio_impares = suma_impares / conteo_impares;
      console.log("El promedio de los números impares es:", promedio_impares);
    }
  }

  ejercicio31() {
    let contador, horasTrabajadas, tarifaPago, salario, sumatoriaSalarios;
    contador = 1;
    sumatoriaSalarios = 0;

    while (contador <= 5) {
      console.log(
        "Ingrese las horas trabajadas de la persona " + contador + ":"
      );
      horasTrabajadas = parseFloat(leer());

      console.log(
        "Ingrese la tarifa de pago por hora de la persona " + contador + ":"
      );
      tarifaPago = parseFloat(leer());

      salario = horasTrabajadas * tarifaPago;
      sumatoriaSalarios += salario;

      console.log("El salario de la persona " + contador + " es: " + salario);
      console.log("");

      contador++;
    }

    console.log("La sumatoria de todos los salarios es: " + sumatoriaSalarios);
  }
}

const ejercicios = new Ejercicios();

// ejercicios.ejercicio1();
// ejercicios.ejercicio2();
// ejercicios.ejercicio3();
// ejercicios.ejercicio4();
// ejercicios.ejercicio5();
// ejercicios.ejercicio6();
// ejercicios.ejercicio7();
// ejercicios.ejercicio8();
// ejercicios.ejercicio9();
// ejercicios.ejercicio10();
// ejercicios.ejercicio11();
// ejercicios.ejercicio12();
// ejercicios.ejercicio13();
// ejercicios.ejercicio14();
// ejercicios.ejercicio15();
// ejercicios.ejercicio16();
// ejercicios.ejercicio17();
// ejercicios.ejercicio18();
// ejercicios.ejercicio19();
// ejercicios.ejercicio20();
// ejercicios.ejercicio21();
// ejercicios.ejercicio22();
// ejercicios.ejercicio23();
// ejercicios.ejercicio24();
// ejercicios.ejercicio25();
// ejercicios.ejercicio26();
// ejercicios.ejercicio27();
// ejercicios.ejercicio28();
// ejercicios.ejercicio29();
// ejercicios.ejercicio30();
// ejercicios.ejercicio31();
